package com.arb2;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(Arb2Mod.MOD_ID)
public class Arb2Mod {
	public static final String MOD_ID = "arb2";

	public static final DeferredRegister<EntityType<?>> ENTITIES =
		DeferredRegister.create(Registries.ENTITY_TYPE, MOD_ID);
	public static final DeferredRegister<Item> ITEMS =
		DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);

	public static final RegistryObject<EntityType<Arb2Entity>> ARB2_ENTITY = ENTITIES.register("arb2",
		() -> EntityType.Builder.<Arb2Entity>of(Arb2Entity::new, MobCategory.MISC)
			.sized(3.2f, 2.6f)
			.clientTrackingRange(10)
			.updateInterval(1)
			.build("arb2"));

	public static final RegistryObject<Item> ARB2_ITEM = ITEMS.register("arb2",
		() -> new Arb2Item(new Item.Properties().stacksTo(1)));

	public Arb2Mod() {
		IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
		ENTITIES.register(bus);
		ITEMS.register(bus);
		bus.addListener(this::addCreative);
	}

	private void addCreative(BuildCreativeModeTabContentsEvent event) {
		if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			event.accept(ARB2_ITEM.get());
		}
	}
}
