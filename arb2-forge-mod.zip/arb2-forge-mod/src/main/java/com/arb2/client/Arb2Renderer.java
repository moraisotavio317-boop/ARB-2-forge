package com.arb2.client;

import com.arb2.Arb2Entity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * Desenha o ARB-2 só com caixas coloridas (sem modelo .json).
 * Textura = paleta 4x4: cada cor é um quadradinho; as caixas apontam pro centro dele.
 * Orientação local: +Z = frente do veículo (rampa), +X = esquerda.
 */
public class Arb2Renderer extends EntityRenderer<Arb2Entity> {
	private static final ResourceLocation TEXTURE =
		ResourceLocation.fromNamespaceAndPath("arb2", "textures/entity/arb2.png");

	private static final int LIGHT_BLUE = 0, BLACK = 1, YELLOW = 2, RED = 3, WHITE = 4, TIRE = 5, GLASS = 6, METAL = 7;

	private static final float RAMP_TIP_Z = 4.6f, RAMP_TIP_Y = 0.35f, RAMP_BACK_Z = 1.8f, RAMP_BACK_Y = 1.35f;

	public Arb2Renderer(EntityRendererProvider.Context ctx) {
		super(ctx);
		this.shadowRadius = 1.6f;
	}

	@Override
	public ResourceLocation getTextureLocation(Arb2Entity entity) {
		return TEXTURE;
	}

	@Override
	public void render(Arb2Entity entity, float yaw, float partialTick, PoseStack poseStack,
	                   MultiBufferSource buffer, int light) {
		poseStack.pushPose();
		poseStack.mulPose(Axis.YP.rotationDegrees(-yaw));
		VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
		PoseStack.Pose e = poseStack.last();

		// chassi + rampa
		box(e, vc, light, BLACK, -1.2f, 0.45f, -4.5f, 1.2f, 1.35f, 1.8f);
		ramp(e, vc, light);

		// luzes amarelas laterais e lanternas traseiras
		for (float z : new float[]{-3.6f, -2.2f, -0.8f, 0.6f}) {
			box(e, vc, light, YELLOW, 1.2f, 0.6f, z, 1.23f, 0.8f, z + 0.25f);
			box(e, vc, light, YELLOW, -1.23f, 0.6f, z, -1.2f, 0.8f, z + 0.25f);
		}
		box(e, vc, light, RED, 0.6f, 0.7f, -4.53f, 1.0f, 0.95f, -4.5f);
		box(e, vc, light, RED, -1.0f, 0.7f, -4.53f, -0.6f, 0.95f, -4.5f);

		// cabine
		box(e, vc, light, LIGHT_BLUE, -1.0f, 1.35f, 0.2f, 1.0f, 2.6f, 1.8f);
		box(e, vc, light, GLASS, -0.85f, 1.75f, 1.8f, 0.85f, 2.45f, 1.83f);
		box(e, vc, light, GLASS, 1.0f, 1.8f, 0.7f, 1.03f, 2.45f, 1.6f);
		box(e, vc, light, GLASS, -1.03f, 1.8f, 0.7f, -1.0f, 2.45f, 1.6f);
		box(e, vc, light, WHITE, -0.6f, 2.6f, 0.8f, 0.6f, 2.75f, 1.6f);

		// escapamentos
		box(e, vc, light, WHITE, 0.85f, 1.35f, -0.05f, 1.0f, 3.3f, 0.1f);
		box(e, vc, light, WHITE, -1.0f, 1.35f, -0.05f, -0.85f, 3.3f, 0.1f);

		// mastro meteorológico
		box(e, vc, light, METAL, -0.07f, 1.35f, -2.2f, 0.07f, 4.6f, -2.06f);
		box(e, vc, light, METAL, -0.5f, 4.5f, -2.2f, 0.5f, 4.58f, -2.06f);
		box(e, vc, light, WHITE, 0.4f, 4.58f, -2.22f, 0.6f, 4.7f, -2.04f);
		box(e, vc, light, WHITE, -0.6f, 4.58f, -2.22f, -0.4f, 4.7f, -2.04f);

		// âncoras: poste vermelho + espeto (desce até o chão quando travado)
		float tipBottom = entity.isAnchored() ? 0.0f : 0.7f;
		for (float z : new float[]{1.2f, -0.2f, -1.4f, -2.6f, -3.8f}) {
			for (float side : new float[]{1.27f, -1.27f}) {
				box(e, vc, light, RED, side - 0.06f, 0.9f, z, side + 0.06f, 2.0f, z + 0.12f);
				box(e, vc, light, METAL, side - 0.04f, tipBottom, z + 0.02f, side + 0.04f, 0.9f, z + 0.1f);
			}
		}

		// rodas
		for (float zc : new float[]{0.7f, -3.0f, -3.95f}) {
			box(e, vc, light, TIRE, 1.0f, 0.0f, zc - 0.45f, 1.45f, 0.9f, zc + 0.45f);
			box(e, vc, light, TIRE, -1.45f, 0.0f, zc - 0.45f, -1.0f, 0.9f, zc + 0.45f);
		}

		poseStack.popPose();
		super.render(entity, yaw, partialTick, poseStack, buffer, light);
	}

	// ------------------------------------------------------------------ helpers

	private static float rampY(float z) {
		return RAMP_TIP_Y + (RAMP_BACK_Y - RAMP_TIP_Y) * (RAMP_TIP_Z - z) / (RAMP_TIP_Z - RAMP_BACK_Z);
	}

	private void ramp(PoseStack.Pose e, VertexConsumer vc, int light) {
		float x0 = -1.2f, x1 = 1.2f;
		float dy = RAMP_BACK_Y - RAMP_TIP_Y, dz = RAMP_TIP_Z - RAMP_BACK_Z;
		float len = (float) Math.sqrt(dy * dy + dz * dz);
		float ny = dz / len, nz = dy / len;

		quad(e, vc, light, LIGHT_BLUE, 0, ny, nz,
			x0, RAMP_TIP_Y, RAMP_TIP_Z, x1, RAMP_TIP_Y, RAMP_TIP_Z,
			x1, RAMP_BACK_Y, RAMP_BACK_Z, x0, RAMP_BACK_Y, RAMP_BACK_Z);
		quad(e, vc, light, BLACK, 1, 0, 0,
			x1, RAMP_TIP_Y, RAMP_TIP_Z, x1, RAMP_TIP_Y, RAMP_BACK_Z,
			x1, RAMP_BACK_Y, RAMP_BACK_Z, x1, RAMP_TIP_Y, RAMP_TIP_Z);
		quad(e, vc, light, BLACK, -1, 0, 0,
			x0, RAMP_TIP_Y, RAMP_BACK_Z, x0, RAMP_TIP_Y, RAMP_TIP_Z,
			x0, RAMP_TIP_Y, RAMP_TIP_Z, x0, RAMP_BACK_Y, RAMP_BACK_Z);
		float[][] stripes = {{3.9f, 3.6f}, {3.2f, 2.9f}, {2.5f, 2.2f}};
		for (float[] s : stripes) {
			quad(e, vc, light, YELLOW, 0, ny, nz,
				-1.0f, rampY(s[0]) + 0.02f, s[0], 1.0f, rampY(s[0]) + 0.02f, s[0],
				1.0f, rampY(s[1]) + 0.02f, s[1], -1.0f, rampY(s[1]) + 0.02f, s[1]);
		}
	}

	private static void box(PoseStack.Pose e, VertexConsumer vc, int light, int sw,
	                        float x0, float y0, float z0, float x1, float y1, float z1) {
		quad(e, vc, light, sw, 1, 0, 0, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1);
		quad(e, vc, light, sw, -1, 0, 0, x0, y0, z1, x0, y1, z1, x0, y1, z0, x0, y0, z0);
		quad(e, vc, light, sw, 0, 1, 0, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0);
		quad(e, vc, light, sw, 0, -1, 0, x0, y0, z1, x0, y0, z0, x1, y0, z0, x1, y0, z1);
		quad(e, vc, light, sw, 0, 0, 1, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1);
		quad(e, vc, light, sw, 0, 0, -1, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0);
	}

	private static void quad(PoseStack.Pose e, VertexConsumer vc, int light, int sw,
	                         float nx, float ny, float nz,
	                         float ax, float ay, float az, float bx, float by, float bz,
	                         float cx, float cy, float cz, float dx, float dy, float dz) {
		float u = (sw % 4) * 0.25f + 0.125f;
		float v = (sw / 4) * 0.25f + 0.125f;
		vert(e, vc, light, u, v, nx, ny, nz, ax, ay, az);
		vert(e, vc, light, u, v, nx, ny, nz, bx, by, bz);
		vert(e, vc, light, u, v, nx, ny, nz, cx, cy, cz);
		vert(e, vc, light, u, v, nx, ny, nz, dx, dy, dz);
	}

	private static void vert(PoseStack.Pose e, VertexConsumer vc, int light, float u, float v,
	                         float nx, float ny, float nz, float x, float y, float z) {
		vc.addVertex(e, x, y, z)
			.setColor(255, 255, 255, 255)
			.setUv(u, v)
			.setOverlay(OverlayTexture.NO_OVERLAY)
			.setLight(light)
			.setNormal(e, nx, ny, nz);
	}
}
