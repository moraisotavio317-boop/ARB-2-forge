package com.arb2;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * ARB-2: veículo de 2 lugares.
 *  - W/S acelera/ré, A/D esterça
 *  - Shift + botão direito: crava / solta as âncoras (trava o veículo)
 *  - Sobe degraus de 1 bloco sozinho
 */
public class Arb2Entity extends Entity {
	private static final EntityDataAccessor<Boolean> ANCHORED =
		SynchedEntityData.defineId(Arb2Entity.class, EntityDataSerializers.BOOLEAN);

	private static final double MAX_FORWARD = 0.75;
	private static final double MAX_REVERSE = 0.25;
	private static final double ACCEL = 0.02;
	private static final double BRAKE = 0.05;

	public Arb2Entity(EntityType<? extends Arb2Entity> type, Level level) {
		super(type, level);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		builder.define(ANCHORED, false);
	}

	public boolean isAnchored() {
		return this.entityData.get(ANCHORED);
	}

	public void setAnchored(boolean anchored) {
		this.entityData.set(ANCHORED, anchored);
	}

	@Override
	protected void readAdditionalSaveData(CompoundTag tag) {
		setAnchored(tag.getBoolean("Anchored"));
	}

	@Override
	protected void addAdditionalSaveData(CompoundTag tag) {
		tag.putBoolean("Anchored", isAnchored());
	}

	@Override
	public boolean isPickable() {
		return !this.isRemoved();
	}

	// ---------------------------------------------------------------- interação

	@Override
	public InteractionResult interact(Player player, InteractionHand hand) {
		if (player.isShiftKeyDown()) {
			if (!level().isClientSide) {
				setAnchored(!isAnchored());
				player.displayClientMessage(
					Component.translatable(isAnchored() ? "message.arb2.anchored" : "message.arb2.released"), true);
				level().playSound(null, blockPosition(),
					isAnchored() ? SoundEvents.PISTON_EXTEND : SoundEvents.PISTON_CONTRACT,
					SoundSource.NEUTRAL, 1.0f, 0.8f);
			}
			return InteractionResult.sidedSuccess(level().isClientSide);
		}
		if (getPassengers().size() >= 2) return InteractionResult.PASS;
		if (!level().isClientSide) {
			return player.startRiding(this) ? InteractionResult.CONSUME : InteractionResult.PASS;
		}
		return InteractionResult.SUCCESS;
	}

	@Override
	public boolean hurt(DamageSource source, float amount) {
		if (isInvulnerableTo(source)) return false;
		if (level().isClientSide || isRemoved()) return true;
		if (source.getEntity() instanceof Player p && !hasPassenger(p)) {
			if (!p.isCreative()) spawnAtLocation(new ItemStack(Arb2Mod.ARB2_ITEM.get()));
			discard();
			return true;
		}
		return false;
	}

	// ---------------------------------------------------------------- passageiros

	@Override
	protected boolean canAddPassenger(Entity passenger) {
		return getPassengers().size() < 2;
	}

	@Nullable
	@Override
	public LivingEntity getControllingPassenger() {
		return getFirstPassenger() instanceof LivingEntity le ? le : null;
	}

	/** Banco 0 = motorista (esquerda), banco 1 = carona (direita), dentro da cabine. */
	@Override
	protected Vec3 getPassengerAttachmentPoint(Entity passenger, EntityDimensions dimensions, float partialTick) {
		int index = getPassengers().indexOf(passenger);
		double x = index <= 0 ? 0.45 : -0.45;
		return new Vec3(x, 0.9, 0.95).yRot(-this.getYRot() * ((float) Math.PI / 180f));
	}

	// ---------------------------------------------------------------- movimento

	@Override
	public void tick() {
		super.tick();
		if (this.isControlledByLocalInstance()) {
			this.drive();
			this.move(MoverType.SELF, this.getDeltaMovement());
		} else {
			this.setDeltaMovement(Vec3.ZERO);
		}
	}

	private void drive() {
		LivingEntity pilot = getControllingPassenger();
		boolean anchored = isAnchored();
		float throttle = 0f;
		float steer = 0f;
		if (pilot != null && !anchored) {
			throttle = pilot.zza;   // W = +, S = -
			steer = pilot.xxa;      // A = + (esquerda), D = - (direita)
		}

		Vec3 vel = getDeltaMovement();
		float yawRad = getYRot() * ((float) Math.PI / 180f);
		double fx = -Mth.sin(yawRad);
		double fz = Mth.cos(yawRad);
		double speed = vel.x * fx + vel.z * fz;

		if (anchored) {
			speed = 0;
		} else if (throttle == 0) {
			speed *= 0.94;
			if (Math.abs(speed) < 0.003) speed = 0;
		} else {
			double target = throttle > 0 ? throttle * MAX_FORWARD : throttle * MAX_REVERSE;
			speed += Mth.clamp(target - speed, -BRAKE, ACCEL);
		}

		if (steer != 0 && Math.abs(speed) > 0.02) {
			float grip = (float) Math.min(1.0, Math.abs(speed) / 0.3);
			setYRot(getYRot() - steer * 3.2f * grip * (float) Math.signum(speed));
			yawRad = getYRot() * ((float) Math.PI / 180f);
			fx = -Mth.sin(yawRad);
			fz = Mth.cos(yawRad);
		}

		double vy;
		if (onGround()) {
			vy = (this.horizontalCollision && Math.abs(speed) > 0.05) ? 0.42 : -0.05;
		} else {
			vy = (vel.y - 0.08) * 0.98;
		}
		setDeltaMovement(fx * speed, vy, fz * speed);
	}
}
