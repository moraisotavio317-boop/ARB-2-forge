package com.arb2;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Item que coloca o ARB-2 no chão. */
public class Arb2Item extends Item {
	public Arb2Item(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult useOn(UseOnContext ctx) {
		Level level = ctx.getLevel();
		if (level.isClientSide) return InteractionResult.SUCCESS;

		BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
		Arb2Entity vehicle = new Arb2Entity(Arb2Mod.ARB2_ENTITY.get(), level);
		vehicle.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, ctx.getRotation(), 0f);
		level.addFreshEntity(vehicle);
		ctx.getItemInHand().consume(1, ctx.getPlayer());
		return InteractionResult.CONSUME;
	}
}
