# ARB-2 (Forge 1.21.1)
Mesmo veículo da versão Fabric. Item "ARB-2" na aba Ferramentas e Utilidades (criativo).
Botão direito = entrar | W/A/S/D dirige | Shift + botão direito = cravar/soltar âncoras.
Build: `gradle build` (Gradle 8.8 + JDK 21). Jar em build/libs/arb2-1.0.0.jar
